import XCTest
@testable import CMSObjects

final class AnyCodableValueTests: XCTestCase {

    func testStringRoundtrip() throws {
        let value: AnyCodableValue = .string("hello")
        let data = try JSONEncoder().encode(value)
        let decoded = try JSONDecoder().decode(AnyCodableValue.self, from: data)
        XCTAssertEqual(value, decoded)
    }

    func testIntRoundtrip() throws {
        let value: AnyCodableValue = .int(42)
        let data = try JSONEncoder().encode(value)
        let decoded = try JSONDecoder().decode(AnyCodableValue.self, from: data)
        XCTAssertEqual(value, decoded)
    }

    func testBoolRoundtrip() throws {
        let value: AnyCodableValue = .bool(true)
        let data = try JSONEncoder().encode(value)
        let decoded = try JSONDecoder().decode(AnyCodableValue.self, from: data)
        XCTAssertEqual(value, decoded)
    }

    func testNullRoundtrip() throws {
        let value: AnyCodableValue = .null
        let data = try JSONEncoder().encode(value)
        let decoded = try JSONDecoder().decode(AnyCodableValue.self, from: data)
        XCTAssertEqual(value, decoded)
    }

    func testNestedDictionaryRoundtrip() throws {
        let value: AnyCodableValue = .dictionary([
            "name": .string("test"),
            "count": .int(5),
            "nested": .dictionary([
                "items": .array([.string("a"), .string("b")]),
                "active": .bool(true)
            ])
        ])
        let data = try JSONEncoder().encode(value)
        let decoded = try JSONDecoder().decode(AnyCodableValue.self, from: data)
        XCTAssertEqual(value, decoded)
    }

    func testSubscriptAccess() {
        let value: AnyCodableValue = .dictionary(["key": .string("value")])
        XCTAssertEqual(value["key"]?.stringValue, "value")
        XCTAssertNil(value["missing"])
    }

    func testArraySubscript() {
        let value: AnyCodableValue = .array([.int(1), .int(2), .int(3)])
        XCTAssertEqual(value[0]?.intValue, 1)
        XCTAssertEqual(value[2]?.intValue, 3)
        XCTAssertNil(value[5])
    }

    func testLiteralExpressions() {
        let s: AnyCodableValue = "hello"
        XCTAssertEqual(s.stringValue, "hello")

        let i: AnyCodableValue = 42
        XCTAssertEqual(i.intValue, 42)

        let b: AnyCodableValue = true
        XCTAssertEqual(b.boolValue, true)
    }

    func testPaginationMeta() {
        let meta = PaginationMeta(page: 2, perPage: 10, total: 25)
        XCTAssertEqual(meta.totalPages, 3)

        let meta2 = PaginationMeta(page: 1, perPage: 10, total: 10)
        XCTAssertEqual(meta2.totalPages, 1)

        let meta3 = PaginationMeta(page: 1, perPage: 10, total: 0)
        XCTAssertEqual(meta3.totalPages, 0)
    }
}
